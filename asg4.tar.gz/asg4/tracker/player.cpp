#include "player.h"
#include "gameData.h"
#include "imageFactory.h"
#include "smartSprite.h"

void Player::advanceFrame(Uint32 ticks) {
  timeSinceLastFrame += ticks;
  if (timeSinceLastFrame > frameInterval) {
    currentFrame = (currentFrame + 1) % numberOfFrames;
    timeSinceLastFrame = 0;
  }
}

void Player::setFlip() { flip = true; }
void Player::clearFlip() { flip = false; }

// TODO: Write the code to implement change the velocity by rand function.
Vector2f Player::makeVelocity(int vx, int vy) const {
  // float newvx = Gamedata::getInstance().getRandFloat(vx-50,vx+50);;
  // float newvy = Gamedata::getInstance().getRandFloat(vy-50,vy+50);;
  // newvx *= [](){ if(rand()%2) return -1; else return 1; }();
  // newvy *= [](){ if(rand()%2) return -1; else return 1; }();

  // return Vector2f(newvx, newvy);
  return Vector2f(vx, vy);
}

Player::Player(const std::string& name)
    : Drawable(name,
               Vector2f(makeVelocity(Gamedata::getInstance().getXmlInt(name + "/startLoc/x"),
                                     Gamedata::getInstance().getXmlInt(name + "/startLoc/y"))),
               Vector2f(makeVelocity(Gamedata::getInstance().getXmlInt(name + "/speedX"),
                                     Gamedata::getInstance().getXmlInt(name + "/speedY")))),
      images(ImageFactory::getInstance().getImages(name)),
      observers(),
      currentFrame(0),
      flip(false),
      numberOfFrames(Gamedata::getInstance().getXmlInt(name + "/frames")),
      frameInterval(Gamedata::getInstance().getXmlInt(name + "/frameInterval")),
      timeSinceLastFrame(0),
      initialVelocity(getVelocity()),
      worldWidth(Gamedata::getInstance().getXmlInt("world/width")),
      worldHeight(Gamedata::getInstance().getXmlInt("world/height")),
      slip(Gamedata::getInstance().getXmlFloat("slip")) {}

Player::Player(const Player& s)
    : Drawable(s),
      images(s.images),
      observers(s.observers),
      currentFrame(s.currentFrame),
      flip(s.flip),
      numberOfFrames(s.numberOfFrames),
      frameInterval(s.frameInterval),
      timeSinceLastFrame(s.timeSinceLastFrame),
      initialVelocity(s.initialVelocity),
      worldWidth(s.worldWidth),
      worldHeight(s.worldHeight),
      slip(s.slip) {}

Player& Player::operator=(const Player& s) {
  Drawable::operator=(s);
  images = (s.images);
  observers = s.observers;
  currentFrame = (s.currentFrame);
  flip = (s.flip);
  numberOfFrames = (s.numberOfFrames);
  frameInterval = (s.frameInterval);
  timeSinceLastFrame = (s.timeSinceLastFrame);
  initialVelocity = (s.initialVelocity);
  worldWidth = (s.worldWidth);
  worldHeight = (s.worldHeight);
  slip = (s.slip);
  return *this;
}

void Player::draw() const {
  if (flip) {
    images[currentFrame]->draw(getX(), getY(), getScale(), true, 1);
  } else {
    images[currentFrame]->draw(getX(), getY(), getScale(), false, 1);
  }
}

void Player::stop() {
  // player.setVelocity( Vector2f(0, 0) );
  setVelocityX(getVelocityX() * slip);
  // player.setVelocityX(0);
  setVelocityY(0);
}

void Player::right() {
  if (getX() < worldWidth - getScaledWidth()) {
    setVelocityX(initialVelocity[0]);
    clearFlip();
  }
}
void Player::left() {
  if (getX() > 0) {
    setVelocityX(-initialVelocity[0]);
    setFlip();
  }
}
void Player::up() {
  if (getY() > 0) {
    setVelocityY(-initialVelocity[1]);
  }
}
void Player::down() {
  if (getY() < worldHeight - getScaledHeight()) {
    setVelocityY(initialVelocity[1]);
  }
}

void Player::detach(SmartSprite* o) {
  std::list<SmartSprite*>::iterator ptr = observers.begin();
  while (ptr != observers.end()) {
    if (*ptr == o) {
      ptr = observers.erase(ptr);
      return;
    }
    ++ptr;
  }
}

void Player::update(Uint32 ticks) {
  // player.update(ticks);
  advanceFrame(ticks);

  Vector2f incr = getVelocity() * static_cast<float>(ticks) * 0.001;
  setPosition(getPosition() + incr);
  // setPosition(getPosition() + incr);

  if (getY() < 0) {
    setVelocityY(fabs(getVelocityY()));
  }
  if (getY() > worldHeight - getScaledHeight()) {
    setVelocityY(-fabs(getVelocityY()));
  }

  if (getX() < 0) {
    setVelocityX(fabs(getVelocityX()));
    // flip = false;
  }
  if (getX() > worldWidth - getScaledWidth()) {
    setVelocityX(-fabs(getVelocityX()));
    // flip = true;
  }
  notify();
  stop();
}

void Player::notify() {
  std::list<SmartSprite*>::iterator ptr = observers.begin();
  while (ptr != observers.end()) {
    (*ptr)->setPlayerPos(getPosition());
    ++ptr;
  }
  stop();
}
