#ifndef _PLAYER__H
#define _PLAYER__H

#include <SDL.h>
#include <cmath>
#include <list>
#include <string>
#include <vector>
#include "bulletPool.h"
#include "drawable.h"

// #include "twoWayMultisprite.h"

class SmartSprite;
class ExplodingSprite;

class Player : public Drawable {
 public:
  Player(const std::string&);
  
  virtual ~Player();

  virtual void draw() const;
  virtual void update(Uint32 ticks);
  // const TwoWayMultiSprite* getPlayer() const { return &player; }

  // const std::string& getName() const { return player.getName(); }

  virtual const Image* getImage() const { return images[currentFrame]; }
  // const Image* getImage() const { return getImage(); }
  int getScaledWidth() const { return getScale() * images[currentFrame]->getWidth(); }
  int getScaledHeight() const { return getScale() * images[currentFrame]->getHeight(); }
  virtual const SDL_Surface* getSurface() const { return images[currentFrame]->getSurface(); }

  Vector2f makeVelocity(int vx, int vy) const;
  void right();
  void left();
  void up();
  void down();
  void stop();

  void setFlip();
  void clearFlip();

  void attach(SmartSprite* o) { observers.emplace_back(o); }
  void detach(SmartSprite* o);
  void notify();

  bool collided(const Drawable* obj) const { return bullets.collidedWith(obj); }

  void shoot();
  void changeBullet();
  void resetBullet() { bullets.resetBullet(); }

  void attack1();
  void attack2();
  void attack3();
  void jumpattack();
  void jump();
  void run();
  // void hurt();
  unsigned int getActiveBulletCount() { return bullets.bulletCount(); }
  unsigned int getFreeBulletCount() { return bullets.freeCount(); }
  void changeImages(const std::string name) {
    std::map<std::string, std::vector<Image*> >::const_iterator pos = multiImages.find(name);
    if (pos != multiImages.end()) {
      images =  pos->second;
    }
  }

  void explode();
  virtual bool hasExplode() { return explodeDone; }
  virtual void setExplodeDone(bool e) {  explodeDone = e; }

  bool getFlip() const { return flip; }
  unsigned int getLivesLeft() const { return livesLeft; }
  // void getLivesLeft() const { return livesLeft; }
  void loseLife() { --livesLeft; }
  bool isGodMode() const { return godMode; }
  void toggleGodMode() { godMode = !godMode; }

 private:
  std::map < std::string, std::vector<Image*>> multiImages;
  std::vector<Image*> images;
  std::vector<Image*> run_images;
  unsigned int livesLeft;
  bool godMode;
  bool explodeDone;
  ExplodingSprite* explosion;
  std::string bulletName;
  BulletPool bullets;
  float minSpeed;
  std::list<SmartSprite*> observers;
  unsigned currentFrame;
  bool flip;
  unsigned numberOfFrames;
  unsigned frameInterval;
  float timeSinceLastFrame;
  Vector2f initialVelocity;
  int worldWidth;
  int worldHeight;
  int limitTop;
  int limitBotton;
  float slip;
  void advanceFrame(Uint32 ticks);
  Player(const Player&) = delete;
  Player& operator=(const Player&) = delete;

};
#endif
