#include "hud.h"
#include <SDL.h>
#include "gameData.h"
#include "ioMod.h"

const SDL_Color color = {255, 255, 0, 255};

Hud::Hud()
    : x(Gamedata::getInstance().getXmlInt("hud/x")),
      y(Gamedata::getInstance().getXmlInt("hud/y")),
      width(Gamedata::getInstance().getXmlInt("hud/w")),
      height(Gamedata::getInstance().getXmlInt("hud/h")),
      c(color),
      io(IoMod::getInstance()) {}

Hud& Hud::getInstance() {
  static Hud instance;
  return instance;
}

void Hud::display(SDL_Renderer* renderer) {
  SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
  SDL_SetRenderDrawColor(renderer, 106, 106, 106, 200);

  SDL_Rect r;
  r.x = x;
  r.y = y;
  r.w = width;
  r.h = height;

  SDL_RenderFillRect(renderer, &r);

  SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255 / 2);
  SDL_RenderDrawRect(renderer, &r);
  io.writeText("W: Go Up", c, 350, 120);
  io.writeText("S: Go Down", c, 350, 160);
  io.writeText("A: Go Left", c, 350, 200);
  io.writeText("D: Go right", c, 350, 240);
  io.writeText("M: Change Collision Strategy", c, 350, 280);
  io.writeText("T: Change Track Object", c, 350, 320);

  SDL_RenderPresent(renderer);
}
