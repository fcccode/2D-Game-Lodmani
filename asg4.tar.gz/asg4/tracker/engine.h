#ifndef _ENGINE__H
#define _ENGINE__H

#include <SDL.h>
#include <vector>
#include "clock.h"
#include "ioMod.h"
#include "renderContext.h"
#include "viewport.h"
#include "world.h"
#include "hud.h"

class Player;
class CollisionStrategy;
class SmartSprite;

class Engine {
 public:
  Engine();
  ~Engine();
  void play();
  void switchSprite();

 private:
  const RenderContext& rc;
  const IoMod& io;
  Clock& clock;
  SDL_Renderer* const renderer;
  std::vector<World*> world;
  Viewport& viewport;
  Player* player;
  // std::vector<Drawable*> sprites; 
  std::vector<SmartSprite*> smart_sprites;
  std::vector<CollisionStrategy*> strategies;
  int currentStrategy;
  int currentSprite;
  mutable bool collision;
  const std::string USERNAME;
  bool makeVideo;

  void draw() const;
  void update(Uint32);

  Engine(const Engine&) = delete;
  Engine& operator=(const Engine&) = delete;
  void printScales() const;
  void checkForCollisions();
};


#endif