#ifndef _PLAYER__H
#define _PLAYER__H

#include <SDL.h>
#include <cmath>
#include <list>
#include <string>
#include <vector>
#include "drawable.h"
// #include "twoWayMultisprite.h"

class SmartSprite;

class Player : public Drawable {
 public:
  Player(const std::string&);
  Player(const Player&);
  virtual ~Player() {}

  virtual void draw() const;
  virtual void update(Uint32 ticks);
  // const TwoWayMultiSprite* getPlayer() const { return &player; }

  // const std::string& getName() const { return player.getName(); }

  const Image* getImage() const { return getImage(); }
  int getScaledWidth() const { return getScale() * images[currentFrame]->getWidth(); }
  int getScaledHeight() const { return getScale() * images[currentFrame]->getHeight(); }
  virtual const SDL_Surface* getSurface() const { return images[currentFrame]->getSurface(); }

  Vector2f makeVelocity(int vx, int vy) const;
  void right();
  void left();
  void up();
  void down();
  void stop();

  void setFlip();
  void clearFlip();
  // TASK3: AI--Smart sprites can react to the player when
  // the player gets close.
  // PS: Observer Pattern
  void attach(SmartSprite* o) { observers.emplace_back(o); }
  void detach(SmartSprite* o);
  void notify();

 private:
  std::vector<Image*> images;
  std::list<SmartSprite*> observers;
  unsigned currentFrame;
  bool flip;
  unsigned numberOfFrames;
  unsigned frameInterval;
  float timeSinceLastFrame;
  Vector2f initialVelocity;
  int worldWidth;
  int worldHeight;
  float slip;
  void advanceFrame(Uint32 ticks);
  Player& operator=(const Player&);
};
#endif
