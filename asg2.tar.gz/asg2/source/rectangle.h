#include<SDL2/SDL.h>

class Rect{
public:
	Rect(SDL_Renderer *);
	void drawRect(int, int, int, int, SDL_Color);
	Rect& operator=(const Rect& );
private:
	SDL_Renderer  *renderer;
	Rect(const Rect& );
};
