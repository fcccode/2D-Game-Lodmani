#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_render.h>
#include <SDL_ttf.h>
#include "main.h"
#include "rectangle.h"
#include "circle.h"
#include "frameGenerator.h"

#define DRAW_TAICHI
// #define DRAW_HEART

#ifdef DRAW_TAICHI
const std::string TITLE = "Tai Chi Diagram";
#endif

#ifdef DRAW_HEART
const std::string TITLE = "Loving Heart";
#endif

const std::string NAME = "guozet";

const int WIDTH = 1150;
const int HEIGHT = 800;

void writeName(SDL_Renderer *renderer)
{
  TTF_Init();
  TTF_Font *font = TTF_OpenFont("fonts/arial.ttf", 30);
  if (font == NULL)
  {
    throw std::string("error: font not found");
  }
  SDL_Color textColor = {241, 240, 236, 0};
  SDL_Surface *surface =
      TTF_RenderText_Solid(font, TITLE.c_str(), textColor);
  SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);

  int textWidth = surface->w;
  int textHeight = surface->h;
  SDL_FreeSurface(surface);
  SDL_Rect dst = {865, HEIGHT - 40, textWidth, textHeight};

  SDL_RenderCopy(renderer, texture, NULL, &dst);
  SDL_DestroyTexture(texture);
}

/*color*/
const SDL_Color c_b = {56, 61, 55, 255};
const SDL_Color c_b_piece = {77, 74, 82, 255};
const SDL_Color c_w_piece = {241, 240, 236, 255};
const SDL_Color c_backgroud = {177, 110, 55, 255};
const SDL_Color c_board_back = {244, 203, 123, 255};
const SDL_Color c_board_base = {111, 92, 59, 255};
const SDL_Color c_bowl = {111, 92, 59, 255};
const SDL_Color c_bowl_base = {65, 50, 17, 255};

int main(int, char *[])
{
  try
  {
    if (SDL_Init(SDL_INIT_VIDEO) != 0)
    {
      std::cout << "Failed to initialize SDL2" << std::endl;
      return EXIT_FAILURE;
    }

    SDL_Window *window = SDL_CreateWindow(
        TITLE.c_str(),
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        WIDTH,
        HEIGHT,
        SDL_WINDOW_SHOWN);

    SDL_Renderer *renderer = SDL_CreateRenderer(
        window, -1, SDL_RENDERER_SOFTWARE);

    // Background will be rendered in this color:
    SDL_SetRenderDrawColor(renderer, c_backgroud.r,
                           c_backgroud.g, c_backgroud.b,
                           c_backgroud.a);
    SDL_RenderClear(renderer);

    Rect r(renderer);
    Circle c(renderer);

    int width_board = HEIGHT - 50;
    int interval = width_board / 18;
    int edge_val = 25 + (width_board % 18) / 2;
    int left_end = 2 * edge_val + interval * 18;

    r.drawRect(0, 0, left_end, left_end, c_board_base);
    r.drawRect(0, 0, left_end - 6, left_end - 6, c_board_back);

    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

    /* Draw the boundary side on the chessboard */
    for (int i = 0; i < 19; ++i)
    {
      SDL_RenderDrawLine(renderer,
                         edge_val + i * interval, edge_val,
                         edge_val + i * interval, edge_val + interval * 18);
      SDL_RenderDrawLine(renderer,
                         edge_val, edge_val + i * interval,
                         edge_val + interval * 18, edge_val + i * interval);
    }

    /* Draw the boundary side on the chessboard */
    SDL_RenderDrawLine(renderer,
                       edge_val - 5, edge_val - 5,
                       edge_val - 5, edge_val + interval * 18 + 5);
    SDL_RenderDrawLine(renderer,
                       edge_val - 5, edge_val - 5,
                       edge_val + interval * 18 + 5, edge_val - 5);

    SDL_RenderDrawLine(renderer,
                       edge_val + interval * 18 + 5, edge_val - 5,
                       edge_val + interval * 18 + 5, edge_val + interval * 18 + 5);
    SDL_RenderDrawLine(renderer,
                       edge_val - 5, edge_val + interval * 18 + 5,
                       edge_val + interval * 18 + 5, edge_val + interval * 18 + 5);

    /*Draw the spot on the chessboard */
    const int spot_location[] = {3, 9, 15};
    for (int i = 0; i < 3; ++i)
    {
      for (int j = 0; j < 3; ++j)
      {
        c.drawCircle(edge_val + spot_location[i] * interval,
                     edge_val + spot_location[j] * interval, 5, c_b);
      }
    }

#ifdef DRAW_TAICHI
    /* Draw image on the chess board*/
    for (int i = 0; i < 19; ++i)
    {
      for (int j = 0; j < 19; ++j)
      {
        if (1 == gossip[i][j])
        {
          c.drawCircle(edge_val + i * interval,
                       edge_val + j * interval, 12, c_w_piece);
        }
        else if (2 == gossip[i][j])
        {
          c.drawCircle(edge_val + i * interval,
                       edge_val + j * interval, 12, c_b_piece);
        }
        else
        {
          continue;
        }
      }
    }
#endif

#ifdef DRAW_HEART
    /* Draw image on the chess board*/
    for (int i = 0; i < 19; ++i)
    {
      for (int j = 0; j < 19; ++j)
      {
        if (1 == heart[i][j])
        {
          c.drawCircle(edge_val + j * interval,
                       edge_val + i * interval, 12, c_w_piece);
        }
        else if (2 == heart[i][j])
        {
          c.drawCircle(edge_val + j * interval,
                       edge_val + i * interval, 12, c_b_piece);
        }
        else
        {
          continue;
        }
      }
    }
#endif

    /* Draw the bowl on the right side*/
    c.drawCircle(965,
                 205, 60, c_bowl_base);
    c.drawCircle(960,
                 200, 60, c_board_back);
    c.drawCircle(960,
                 180, 40, c_b_piece);

    c.drawCircle(965,
                 585, 60, c_bowl_base);
    c.drawCircle(960,
                 580, 60, c_board_back);
    c.drawCircle(960,
                 560, 40, c_w_piece);

    writeName(renderer);
    SDL_RenderPresent(renderer);
    FrameGenerator frameGen(renderer, window, WIDTH, HEIGHT, NAME);
    frameGen.makeFrame();

    SDL_Event event;
    const Uint8 *keystate;
    while (true)
    {
      keystate = SDL_GetKeyboardState(0);
      if (keystate[SDL_SCANCODE_ESCAPE])
      {
        break;
      }
      if (SDL_PollEvent(&event))
      {
        if (event.type == SDL_QUIT)
        {
          break;
        }
      }
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
  }

  catch (const std::string &msg)
  {
    std::cout << msg << std::endl;
  }
  catch (...)
  {
    std::cout << "Oops, someone threw an exception!" << std::endl;
  }

  return EXIT_SUCCESS;
}
