#include "engine.h"
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <random>
#include <sstream>
#include <string>
#include "frameGenerator.h"
#include "gameData.h"
#include "multisprite.h"
#include "sprite.h"
#include "twoWayMultisprite.h"

const std::string background[] = {"sky",     "sunlight", "rainbow",
                                  "iceberg", "grass",    "ground"};

const std::string sprites_names[] = {
    "RedHairedBoy", "MonsterRun", "MonsterSmallRun", "RedBird",
    "PinkBird",     "JumpBoy",    "JumpBoy2",        "Monster"};

Engine::~Engine() {
  // TASK 8: Drawable* vector
  for (auto* s : sprites) {
    delete s;
  }

  for (auto* w : world) {
    delete w;
  }
  std::cout << "Terminating program" << std::endl;
}

Engine::Engine()
    : rc(RenderContext::getInstance()),
      io(IoMod::getInstance()),
      clock(Clock::getInstance()),
      renderer(rc.getRenderer()),
      world(),
      viewport(Viewport::getInstance()),
      sprites(),
      currentSprite(0),
      USERNAME(Gamedata::getInstance().getXmlStr("username")),
      makeVideo(false) {
  int background_number = sizeof(background) / sizeof(background[0]);
  world.reserve(background_number);
  for (int i = 0; i < background_number; ++i) {
    world.emplace_back(new World(
        background[i],
        Gamedata::getInstance().getXmlInt(background[i] + "/factor")));
  }

  int sprites_number = sizeof(sprites_names) / sizeof(sprites_names[0]);
  sprites.reserve(sprites_number);
  for (int i = 0; i < sprites_number; ++i) {
    int number = Gamedata::getInstance().getXmlInt(sprites_names[i] + "/number");
    for (int j = 0; j < number; ++j) {
      sprites.emplace_back(new TwoWayMultiSprite(sprites_names[i]));
    }
  }

  if (sprites.size() > 0) Viewport::getInstance().setObjectToTrack(sprites[0]);
  std::cout << "Loading complete" << std::endl;
}

void Engine::draw() const {
  for (auto* s : world) {
    s->draw();
  }

  for (auto* s : sprites) {
    s->draw();
  }

  // TASK 4: Add fps information
  std::stringstream strm_fps;
  SDL_Color fpsColor = {2, 113, 192, 0};
  strm_fps << "fps: " << clock.getFps();
  io.writeText(strm_fps.str(), fpsColor, 30, 60);

  // Task 5: Add additional font color
  std::stringstream strm_name;
  SDL_Color nameColor = {255, 255, 255, 0};
  strm_name << Gamedata::getInstance().getXmlStr("authorname");
  int name_loc_x = 30;
  int name_loc_y = Gamedata::getInstance().getXmlInt("view/height") - 40;
  io.writeText(strm_name.str(), nameColor, name_loc_x, name_loc_y);

  viewport.draw();
  SDL_RenderPresent(renderer);
}

void Engine::update(Uint32 ticks) {
  for (auto* s : world) {
    s->update();
  }
  // TASK 8: Drawable* vector
  for (auto* s : sprites) {
    s->update(ticks);
  }

  viewport.update();  // always update viewport last
}

void Engine::switchSprite() {
  ++currentSprite;

  if (sprites.size() > 0) {
    currentSprite = currentSprite % sprites.size();
    if (currentSprite) {
      Viewport::getInstance().setObjectToTrack(sprites[currentSprite]);
    } else {
      Viewport::getInstance().setObjectToTrack(sprites[0]);
    }
  } else {
    std::cout << "[ERROR] Pleas give a sprite." << std::endl;
  }
}

void Engine::play() {
  SDL_Event event;
  const Uint8* keystate;
  bool done = false;
  Uint32 ticks = clock.getElapsedTicks();
  FrameGenerator frameGen;

  while (!done) {
    // The next loop polls for events, guarding against key bounce:
    while (SDL_PollEvent(&event)) {
      keystate = SDL_GetKeyboardState(NULL);
      if (event.type == SDL_QUIT) {
        done = true;
        break;
      }
      if (event.type == SDL_KEYDOWN) {
        if (keystate[SDL_SCANCODE_ESCAPE] || keystate[SDL_SCANCODE_Q]) {
          done = true;
          break;
        }
        if (keystate[SDL_SCANCODE_P]) {
          if (clock.isPaused())
            clock.unpause();
          else
            clock.pause();
        }
        if (keystate[SDL_SCANCODE_T]) {
          switchSprite();
        }
        if (keystate[SDL_SCANCODE_V] && !makeVideo) {
          std::cout << "Initiating frame capture" << std::endl;
          makeVideo = true;
        } else if (keystate[SDL_SCANCODE_V] && makeVideo) {
          std::cout << "Terminating frame capture" << std::endl;
          makeVideo = false;
        }
      }
    }

    // In this section of the event loop we allow key bounce:
    ticks = clock.getElapsedTicks();
    if (ticks > 0) {
      clock.incrFrame();
      draw();
      update(ticks);
      if (makeVideo) {
        frameGen.makeFrame();
      }
    }
  }
}
