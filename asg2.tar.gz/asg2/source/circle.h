#include<SDL2/SDL.h>

class Circle {
public:
	Circle(SDL_Renderer *);
	void drawCircle(int, int, int, SDL_Color);
	void drawCircle(SDL_Renderer*, SDL_Point, int, SDL_Color);
	void drawCircleDown(int, int, int, SDL_Color);
	Circle& operator=(const Circle&);
private:
	SDL_Renderer* renderer;
	Circle(const Circle&);
};
