#include "rectangle.h"
#include <SDL2/SDL.h>
#include <SDL2/SDL_render.h>

Rect::Rect(SDL_Renderer * rend): renderer(rend){}
void Rect::drawRect(int x_, int y_, int w_, 
					int h_, SDL_Color color){
	SDL_Rect t;
	SDL_SetRenderDrawColor( renderer, color.r, color.g, color.b, color.a );
	t.x = x_;
	t.y = y_;
	t.w = w_;
	t.h = h_;
	SDL_RenderFillRect(renderer, &t);
}

Rect& Rect::operator = (const Rect& rend){
	renderer = rend.renderer;
	return *this;
}
