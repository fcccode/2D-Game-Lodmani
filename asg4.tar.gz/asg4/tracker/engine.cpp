#include "engine.h"
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <random>
#include <sstream>
#include <string>
#include "collisionStrategy.h"
#include "frameGenerator.h"
#include "gameData.h"
#include "multisprite.h"
#include "player.h"
#include "smartSprite.h"
#include "sprite.h"
#include "twoWayMultisprite.h"

const std::string background[] = {"sky", "sunlight", "rainbow", "iceberg", "grass", "ground"};

// const std::string sprites_names[] = {
//     "MonsterRun", "MonsterSmallRun", "RedBird", "PinkBird",
//     "JumpBoy",    "JumpBoy2",        "Monster"};
// const std::string smart_sprites_names[] = {"WindSmall"};
const std::string smart_sprites_names[] = {"PinkBird", "RedBird"};

Engine::~Engine() {
  delete player;
  for (auto* w : world) {
    delete w;
  }

  for (auto* ss : smart_sprites) {
    delete ss;
  }

  for (CollisionStrategy* strategy : strategies) {
    delete strategy;
  }

  std::cout << "Terminating program" << std::endl;
}

Engine::Engine()
    : rc(RenderContext::getInstance()),
      io(IoMod::getInstance()),
      clock(Clock::getInstance()),
      renderer(rc.getRenderer()),
      world(),
      viewport(Viewport::getInstance()),
      player(new Player("MonsterRun")),
      // sprites(),
      smart_sprites(),
      strategies(),
      currentStrategy(0),
      currentSprite(1),
      collision(false),
      USERNAME(Gamedata::getInstance().getXmlStr("username")),
      makeVideo(false) {
  int background_number = sizeof(background) / sizeof(background[0]);
  world.reserve(background_number);
  for (int i = 0; i < background_number; ++i) {
    world.emplace_back(new World(background[i], Gamedata::getInstance().getXmlInt(background[i] + "/factor")));
  }

  // TODO: Add some funciton about attack and run fast
  // TODO: Add some other function which doesn't need two way sprite.
  Vector2f pos = player->getPosition();
  int w = player->getScaledWidth();
  int h = player->getScaledHeight();
  int smart_sprites_number = sizeof(smart_sprites_names) / sizeof(smart_sprites_names[0]);

  smart_sprites.reserve(smart_sprites_number);
  for (int i = 0; i < smart_sprites_number; ++i) {
    int number = Gamedata::getInstance().getXmlInt(smart_sprites_names[i] + "/number");
    for (int j = 0; j < number; ++j) {
      smart_sprites.emplace_back(new SmartSprite(smart_sprites_names[i], pos, w, h));
    }
  }
  for (auto* s_sprit : smart_sprites) player->attach(s_sprit);
  // std::cout << "INFO:" << smart_sprites.size() << std::endl;

  // sprites.emplace_back(new Sprite("Wind"));

  strategies.push_back(new RectangularCollisionStrategy);
  strategies.push_back(new PerPixelCollisionStrategy);
  strategies.push_back(new MidPointCollisionStrategy);

  Viewport::getInstance().setObjectToTrack(player);
  // if (sprites.size() > 0)
  // Viewport::getInstance().setObjectToTrack(sprites[0]);
  std::cout << "Loading complete" << std::endl;
}

void Engine::draw() const {
  for (auto* s : world) {
    s->draw();
  }

  player->draw();

  for (auto* s : smart_sprites) {
    s->draw();
  }

  std::stringstream strm_hud;
  SDL_Color hubColor = {255, 255, 255, 0};
  io.writeText("Press F1 to see HUD", 650, 60);
  strm_hud << smart_sprites.size() << " Smart Sprites Remaining";
  io.writeText(strm_hud.str(), hubColor, 30, 60);

  strategies[currentStrategy]->draw();
  if (collision) {
    IoMod::getInstance().writeText("Oops: Collision", 650, 90);
    collision = false;
  }

  std::stringstream strm_fps;
  SDL_Color fpsColor = {2, 113, 192, 0};
  strm_fps << "fps: " << clock.getFps();
  io.writeText(strm_fps.str(), fpsColor, 30, Gamedata::getInstance().getXmlInt("view/height") - 30);

  std::stringstream strm_name;
  SDL_Color nameColor = {255, 255, 255, 0};
  strm_name << Gamedata::getInstance().getXmlStr("authorname");
  int name_loc_x = 30;
  int name_loc_y = Gamedata::getInstance().getXmlInt("view/height") - 60;
  io.writeText(strm_name.str(), nameColor, name_loc_x, name_loc_y);

  viewport.draw();
  SDL_RenderPresent(renderer);
}

void Engine::checkForCollisions() {
  auto it = smart_sprites.begin();
  while (it != smart_sprites.end()) {
    if (strategies[currentStrategy]->execute(player, *it)) {
      collision = true;
      SmartSprite* doa = *it;
      player->detach(doa);
      delete doa;
      it = smart_sprites.erase(it);
    } else
      ++it;
  }
}

void Engine::update(Uint32 ticks) {
  checkForCollisions();
  player->update(ticks);
  for (auto* s : world) {
    s->update();
  }

  for (auto* s : smart_sprites) {
    s->update(ticks);
  }

  viewport.update();  // always update viewport last
}

void Engine::switchSprite() {
  ++currentSprite;

  if (smart_sprites.size() > 0) {
    currentSprite = currentSprite % 2;
    if (currentSprite) {
      Viewport::getInstance().setObjectToTrack(player);
    } else {
      Viewport::getInstance().setObjectToTrack(smart_sprites[0]);
    }
  } else {
    std::cout << "[ERROR] Pleas give a sprite." << std::endl;
  }
}

void Engine::play() {
  SDL_Event event;
  const Uint8* keystate;
  bool done = false;
  Uint32 ticks = clock.getElapsedTicks();
  FrameGenerator frameGen;

  while (!done) {
    // The next loop polls for events, guarding against key bounce:
    while (SDL_PollEvent(&event)) {
      keystate = SDL_GetKeyboardState(NULL);
      if (event.type == SDL_QUIT) {
        done = true;
        break;
      }
      if (event.type == SDL_KEYDOWN) {
        if (keystate[SDL_SCANCODE_ESCAPE] || keystate[SDL_SCANCODE_Q]) {
          done = true;
          break;
        }
        if (keystate[SDL_SCANCODE_P]) {
          if (clock.isPaused())
            clock.unpause();
          else
            clock.pause();
        }
        if (keystate[SDL_SCANCODE_F1]) {
          if (clock.isPaused())
            clock.unpause();
          else {
            clock.pause();
            Hud::getInstance().display(renderer);
          }
        }
        if (keystate[SDL_SCANCODE_T]) {
          switchSprite();
        }
        if (keystate[SDL_SCANCODE_M]) {
          currentStrategy = (1 + currentStrategy) % strategies.size();
        }
        if (keystate[SDL_SCANCODE_V] && !makeVideo) {
          std::cout << "Initiating frame capture" << std::endl;
          makeVideo = true;
        } else if (keystate[SDL_SCANCODE_V] && makeVideo) {
          std::cout << "Terminating frame capture" << std::endl;
          makeVideo = false;
        }
      }
    }

    // In this section of the event loop we allow key bounce:
    ticks = clock.getElapsedTicks();
    if (ticks > 0) {
      clock.incrFrame();
      if (keystate[SDL_SCANCODE_A]) {
        static_cast<Player*>(player)->left();
      }
      if (keystate[SDL_SCANCODE_D]) {
        static_cast<Player*>(player)->right();
      }
      if (keystate[SDL_SCANCODE_W]) {
        static_cast<Player*>(player)->up();
      }
      if (keystate[SDL_SCANCODE_S]) {
        static_cast<Player*>(player)->down();
      }
      if (keystate[SDL_SCANCODE_A] && keystate[SDL_SCANCODE_W]) {
        static_cast<Player*>(player)->left();
        static_cast<Player*>(player)->up();
      }
      if (keystate[SDL_SCANCODE_D] && keystate[SDL_SCANCODE_W]) {
        static_cast<Player*>(player)->right();
        static_cast<Player*>(player)->up();
      }
      if (keystate[SDL_SCANCODE_A] && keystate[SDL_SCANCODE_S]) {
        static_cast<Player*>(player)->left();
        static_cast<Player*>(player)->down();
      }
      if (keystate[SDL_SCANCODE_D] && keystate[SDL_SCANCODE_S]) {
        static_cast<Player*>(player)->right();
        static_cast<Player*>(player)->down();
      }
      draw();
      update(ticks);
      if (makeVideo) {
        frameGen.makeFrame();
      }
    }
  }
}
